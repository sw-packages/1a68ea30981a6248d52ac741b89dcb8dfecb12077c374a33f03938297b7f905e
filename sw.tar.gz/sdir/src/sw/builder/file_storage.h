/*
 * SW - Build System and Package Manager
 * Copyright (C) 2017-2020 Egor Pugin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#pragma once

#include "concurrent_map.h"

#include <primitives/filesystem.h>

namespace sw
{

struct FileData;
struct SwBuilderContext;

struct SW_BUILDER_API FileStorage
{
    using FileDataHashMap = ConcurrentHashMap<path, FileData>;

    FileDataHashMap files;

    void clear(); // remove?
    void reset(); // remove?

    FileData &registerFile(const path &f);
};

}
